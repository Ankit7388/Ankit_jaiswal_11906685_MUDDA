import React from "react";
import "./operations.css";
import ActiveOption from "./ActiveOption";
import DataTable from "../dataTable/DataTable";
import { MdRefresh } from "react-icons/md";
import Buttons from "./Buttons";

let selectedRow = null;
const rowData = (row) =>  {
  selectedRow = row;
  console.log(selectedRow);
}

function Operations() {
  return (
    <div>
      <div className="operations__container">
        <ActiveOption />
        <div className="btn refresher">
          <MdRefresh />
        </div>
        <input placeholder="Search Customer Id" className="searchBar" />
        <Buttons selectedRow={selectedRow} />
      </div>
      <DataTable rowData={rowData} />
    </div>
  );
}

export default Operations;

