import React, { useState } from "react";
import "./buttons.css";
import AddPopUp from "../popups/AddPopUp";
import EditPopUp from "../popups/EditPopUp";
import {Button, Dialog, DialogTitle, DialogContent, DialogActions, makeStyles, ButtonGroup} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  dialogWrapper: {
    padding: theme.spacing(2),
    position: 'absolute',
    backgroundColor: '#1d456ae2',
    color: '#fff'
  },
  dialogButton: {
    border: '1px solid rgba(255, 255, 255)',
    color: '#fff',
    width: '100%',
  },
  buttonWrapper: {
    border: '1px solid #4db5ff',
    color: '#fff',
    padding: '0 80px'
  }
}));

  const Buttons = (props) => {
  const classes = useStyles();
  const [openAdd, setOpenAdd] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [openDelete, setOpenDelete] = useState(false);

  const checkProp = ()=> {
    console.log(props.selectedRow);
  }

  // button disabled
  const [currentRow, setCurrentRow] = useState(props.selectedRow);

  const handleADDClickOpen = () => {
    setOpenAdd(true);
  };

  const handleADDClose = () => {
    setOpenAdd(false);
  };

  const handleEDITClickOpen = () => {
    setOpenEdit(true);
  };

  const handleEDITClickClose = () => {
    setOpenEdit(false);
  };

  const handleDELETEClickOpen = () => {
    setOpenDelete(true);
  };

  const handleDELETEClose = () => {
    setOpenDelete(false);
  };

  return (
    <ButtonGroup className="btn__container">
    <Button variant="outlined" onClick={checkProp}>check</Button>
      <Button className={classes.buttonWrapper}
      variant="outlined" onClick={handleADDClickOpen}>
        ADD
      </Button>
      <Dialog maxWidth="lg" classes={{paper: classes.dialogWrapper}}
      open={openAdd} onClose={handleADDClose}>
        <DialogTitle>Add</DialogTitle>
        <DialogContent>
          <AddPopUp />
        </DialogContent>
        <DialogActions>
          <Button className={classes.dialogButton}
          onClick={handleADDClose} variant="outlined">
            CANCEL
          </Button>
          <Button className={classes.dialogButton}
          onClick={handleADDClose} variant="outlined">
            ADD
          </Button>
        </DialogActions>
      </Dialog>

      <Button className={classes.buttonWrapper}
        variant="outlined"
        onClick={handleEDITClickOpen}
        disabled={!currentRow}
      >
        EDIT
      </Button>
      <Dialog classes={{paper: classes.dialogWrapper}}
      open={openEdit} onClose={handleEDITClickClose}>
        <DialogTitle>EDIT</DialogTitle>
        <DialogContent>
          <EditPopUp />
        </DialogContent>
        <DialogActions>
          <Button className={classes.dialogButton}
          onClick={handleEDITClickClose} variant="outlined">
            CANCEL
          </Button>
          <Button className={classes.dialogButton}
          onClick={handleEDITClickClose} variant="outlined">
            EDIT
          </Button>
        </DialogActions>
      </Dialog>
      <Button className={classes.buttonWrapper}
        variant="outlined"
        onClick={handleDELETEClickOpen}
      >
        DELETE
      </Button>

      <Dialog classes={{paper: classes.dialogWrapper}}
      open={openDelete} onClose={handleDELETEClose}>
        <DialogTitle>DELETE Records ?</DialogTitle>
        <DialogContent>
          Are you sure you want to delete these record[s]?
        </DialogContent>
        <DialogActions>
          <Button className={classes.dialogButton}
           onClick={handleDELETEClose} variant="outlined">
            CANCEL
          </Button>
          <Button className={classes.dialogButton} 
          onClick={handleDELETEClose} variant="outlined">
            DELETE
          </Button>
        </DialogActions>
      </Dialog>
    </ButtonGroup>
  );
}

export default Buttons;
