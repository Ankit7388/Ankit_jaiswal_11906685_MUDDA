import React from 'react'
import TextField from "@material-ui/core/TextField";

export default function AdvanceSearch() {
  return (
    <div className='Grid__container-adv'>
    <TextField label='Document ID' className='Grid__item-adv' />
    <TextField label='Invoice ID' className='Grid__item-adv' />
    <TextField label='Customer Number' className='Grid__item-adv' />
    <TextField label='Buisness Year' className='Grid__item-adv' />
    </div>
  )
}
