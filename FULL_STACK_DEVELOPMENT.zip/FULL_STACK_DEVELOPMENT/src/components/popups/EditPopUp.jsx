import React, { useState } from "react";
import "./EditPopUp.css";
import { TextField } from "@material-ui/core";

function EditPopUp(props) {
  const [InvoiceCurrency, setInvoiceCurrency] = useState('');
  const [CustPaymentTerms, setCustPaymentTerms] = useState('');
  return (
    <div className="Grid__container-edit">
      <TextField
        onChange={(e) => setInvoiceCurrency(e.target.value)}
        value={InvoiceCurrency}
        className="Grid__item-edit"
        label="Invoice Currency"
        variant="outlined"
      />
      <TextField
        onChange={(e) => setCustPaymentTerms(e.target.value)}
        value={CustPaymentTerms}
        className="Grid__item-edit"
        label="Customer Payment Terms"
        variant="outlined"
      />
    </div>
  );
}

export default EditPopUp;
