import React from 'react'

function Footer() {
  return (
    <center><a href='https://www.privacypolicygenerator.info/live.php?token=vW8ze5tS4pZ20HF4jFKSnmzH67uvyN3w' target={1}>Privacy Policy</a> | © 2022 HighRadius Corporation All rights reserved</center>
  )
}

export default Footer