import React from 'react'

function ViewAnalytics() {
  return (
    <div><h1>View Analytics</h1></div>
  )
}

export default ViewAnalytics